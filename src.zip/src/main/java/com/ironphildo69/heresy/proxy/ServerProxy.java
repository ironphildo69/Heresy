package com.ironphildo69.heresy.proxy;

public class ServerProxy implements CommonProxy {

	@Override
	public void init() {}

}
