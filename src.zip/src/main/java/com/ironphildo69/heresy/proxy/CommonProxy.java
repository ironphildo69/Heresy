package com.ironphildo69.heresy.proxy;

public interface CommonProxy {

	public void init();
}
