package com.ironphildo69.heresy.init;

import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModCrafting {

	public static void register() {
		
		//Imperium Blocks
		
		GameRegistry.addShapedRecipe(new ItemStack(ModBlocks.blockplasteel), "CCC", "CCC", "CCC", 'C', ModItems.plasteelingot);
		GameRegistry.addShapedRecipe(new ItemStack(ModItems.imperialguardhelmet), "CCC", "CXC", "XXX", 'C', ModItems.ceramiteingot);
		GameRegistry.addShapedRecipe(new ItemStack(ModItems.imperialguardchest), "CXC", "CCC", "CCC", 'C', ModItems.ceramiteingot);
		GameRegistry.addShapedRecipe(new ItemStack(ModItems.imperialguardlegs), "CCC", "CXC", "CXC", 'C', ModItems.ceramiteingot);
		GameRegistry.addShapedRecipe(new ItemStack(ModItems.imperialguardfeet), "XXX", "CCC", "CXC", 'C', ModItems.ceramiteingot);
		
		
		
	}
}
