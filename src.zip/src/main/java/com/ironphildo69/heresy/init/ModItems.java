package com.ironphildo69.heresy.init;

import com.ironphildo69.heresy.Reference;
import com.ironphildo69.heresy.items.ItemTest;
import com.ironphildo69.heresy.items.imperium.ItemCeramiteIngot;
import com.ironphildo69.heresy.items.imperium.ItemImperialGuardArmor;
import com.ironphildo69.heresy.items.imperium.ItemPlasteelIngot;

import net.minecraftforge.common.util.EnumHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraftforge.fml.common.registry.GameRegistry;

public class ModItems {
	
	//Declares new items.
	
	public static Item test;
	public static Item imperialguardhelmet;
	public static Item imperialguardchest;
	public static Item imperialguardlegs;
	public static Item imperialguardfeet;
	public static Item plasteelingot;
	public static Item ceramiteingot;
	
	//Initializes new items - DONT FORGET THIS
	
	public static void init() {
		test = new ItemTest();
		imperialguardhelmet = new ItemImperialGuardArmor("imperialguardhelmet", ItemImperialGuardArmor.CERAMIC, 1, EntityEquipmentSlot.HEAD);
		imperialguardchest = new ItemImperialGuardArmor("imperialguardchest", ItemImperialGuardArmor.CERAMIC, 1, EntityEquipmentSlot.CHEST);
		imperialguardlegs = new ItemImperialGuardArmor("imperialguardlegs", ItemImperialGuardArmor.CERAMIC, 2, EntityEquipmentSlot.LEGS);
		imperialguardfeet = new ItemImperialGuardArmor("imperialguardfeet", ItemImperialGuardArmor.CERAMIC, 1, EntityEquipmentSlot.FEET);
		
		//Ingots
		
		plasteelingot = new ItemPlasteelIngot();
		ceramiteingot = new ItemCeramiteIngot();
	}
	
	//Registers Items into the Minecraft Item directory - note, don't forget this yet again
	
	public static void register() {
		GameRegistry.register(test);
		GameRegistry.registerItem(imperialguardhelmet = new ItemImperialGuardArmor("itemimperialguardhelmet", ItemImperialGuardArmor.CERAMIC, 1, EntityEquipmentSlot.HEAD), "itemimperialguardhelmet");
		GameRegistry.registerItem(imperialguardchest = new ItemImperialGuardArmor("itemimperialguardchest", ItemImperialGuardArmor.CERAMIC, 1, EntityEquipmentSlot.CHEST), "itemimperialguardchest");
		GameRegistry.registerItem(imperialguardlegs = new ItemImperialGuardArmor("itemimperialguardlegs", ItemImperialGuardArmor.CERAMIC, 1, EntityEquipmentSlot.LEGS), "itemimperialguardlegs");
		GameRegistry.registerItem(imperialguardfeet = new ItemImperialGuardArmor("itemimperialguardfeet", ItemImperialGuardArmor.CERAMIC, 1, EntityEquipmentSlot.FEET), "itemimperialguardfeet");
		
		//Ingots
		
		GameRegistry.register(plasteelingot);
		GameRegistry.register(ceramiteingot);
		
	}
	
	//register the renders for drawing the object
	
	public static void registerRenders() {
		registerRender(test);
		registerRender(imperialguardhelmet);
		registerRender(imperialguardchest);
		registerRender(imperialguardlegs);
		registerRender(imperialguardfeet);
		GameRegistry.register(plasteelingot);
	}
	
	private static void registerRender(Item item) {
		Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
	}
}
