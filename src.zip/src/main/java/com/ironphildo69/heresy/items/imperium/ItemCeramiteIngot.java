package com.ironphildo69.heresy.items.imperium;

import com.ironphildo69.heresy.Reference;
import net.minecraft.item.Item;

public class ItemCeramiteIngot extends Item {

	public ItemCeramiteIngot() {
		setUnlocalizedName(Reference.HeresyItems.ITEMCERAMITEINGOT.getUnlocalizedName());
		setRegistryName(Reference.HeresyItems.ITEMCERAMITEINGOT.getRegistryName());
	}
	
}