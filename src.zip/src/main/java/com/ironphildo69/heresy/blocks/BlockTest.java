package com.ironphildo69.heresy.blocks;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class BlockTest extends Block {

	public BlockTest(Material materialIn) {
		super(materialIn);
		// TODO Auto-generated constructor stub
	}

}
